package com.androidatc.loveall

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_preferences.*

class Preferences : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_preferences)

        //When this activity is pulled up, if the "classic" variable sent to it is true, the box remains checked.
        var classic = intent.getBooleanExtra("classic", false)
        if(classic)
            scoreBox.isChecked = true

        //Handle checking the box.
        returnButton.setOnClickListener {
            var classic = false //assume classic scoring is off.
            if(scoreBox.isChecked) //if Checked, use classic scoring
                classic = true

            //We send the user's choice for this setting to the main activity, so it stays "remembered".
            var intent = Intent(this, MainActivity::class.java)
            intent.putExtra("classic", classic) //return user decision to the game setup screen.
            startActivity(intent)
        }
    }

}