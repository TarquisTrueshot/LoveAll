package com.androidatc.loveall

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_history.*

class History : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_history)

        //Initialize database objects.
        val dbHelper = TennisDBHelper(this)
        val db = dbHelper.writableDatabase

        //Return each game stored in the database.
        val cursor = db.query("Games", arrayOf("player_one", "player_two", "p1_score", "p2_score"), null, null, null, null, null)

        //Populate the textView with data from every match.
        with(cursor){
            while(moveToNext()){
                resultsTxt.text = resultsTxt.text.toString() + "${getString(0)}: ${getString(2)} \n${getString(1)}: ${getString(3)}\n\n"
            }
        }
        cursor.close() //close cursor object to free up resources.

        //Handle user pushing back button.
        backBtn.setOnClickListener {
            onBackPressed()
        }
    }


}