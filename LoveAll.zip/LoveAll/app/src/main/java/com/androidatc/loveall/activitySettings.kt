package com.androidatc.loveall

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_settings.*

class activitySettings : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        //Keep this setting alive!
        var classic = intent.getBooleanExtra("classic", false)

        //Return to the main activity.
        returnBtn2.setOnClickListener {
            var intent = Intent(this, MainActivity::class.java)
            intent.putExtra("classic", classic)
            startActivity(intent)
        }
    }

}