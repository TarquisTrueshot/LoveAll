package com.androidatc.loveall

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*
import android.view.View

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        //Get user choice for classic scoring, or assume modern scoring is used.
        var classic_scoring = intent.getBooleanExtra("classic", false)

        // Declare variables to hold player and game info.
        var player_one_name : String?= null
        var player_two_name : String?= null
        var games_per_set : Int?= null
        var sets_per_Game : Int?= null

        fun go2SecondActivity(view:View) {
            var intent = Intent(this, Scorecard::class.java)
            intent.putExtra("player_one", player_one_name)
            intent.putExtra("player_two", player_two_name)
            intent.putExtra("setsPer", sets_per_Game)
            intent.putExtra("gamesPer", games_per_set)
            intent.putExtra("classic_scoring", classic_scoring)
            startActivity(intent)
        }

        // Process input data and store it, if valid.
        playButton.setOnClickListener {
            if(playerOneInput.text.isNotEmpty() && playerTwoInput.text.isNotEmpty() &&
                gamesInput.text.isNotEmpty() && setsInput.text.isNotEmpty()) {
            player_one_name = playerOneInput.text.toString()
            player_two_name = playerTwoInput.text.toString()
            games_per_set = gamesInput.text.toString().toInt()
            sets_per_Game = setsInput.text.toString().toInt()
            go2SecondActivity(it)

            }

            else { // Inform the user that they did not fill out all fields.
                Toast.makeText(applicationContext, "Please fill in all fields and try again!", Toast.LENGTH_SHORT).show()
            }
        }

        //Open the help page.
        helpButton.setOnClickListener {
            var intent = Intent(this, activitySettings::class.java)
            intent.putExtra("classic", classic_scoring)
            startActivity(intent)
        }

        //Open preferences.
        prefBtn.setOnClickListener {
            var intent = Intent(this, Preferences::class.java)
            intent.putExtra("classic", classic_scoring)
            startActivity(intent)
        }

        //Open History.
        historyBtn.setOnClickListener {
            var intent = Intent(this, History::class.java)
            intent.putExtra("classic", classic_scoring)
            startActivity(intent)
        }
    }
}

