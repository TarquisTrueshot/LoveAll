package com.androidatc.loveall

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

//This class handles creating the database and it's table the first time is the app opened.
//It extends the SQLiteOpenHelper class, that handles a variety of SQLite commands.
class TennisDBHelper(context: Context) : SQLiteOpenHelper(context, "tennisStuff.db", null, 1) {
    override fun onCreate(p0: SQLiteDatabase?) {
        var CREATE_GAMES = "Create Table Games(\n" +
                "G_ID    INTEGER    PRIMARY KEY,\n" +
                "PLAYER_ONE    VARCHAR(35)    NOT NULL,\n" +
                "PLAYER_TWO    VARCHAR(35)    NOT NULL,\n" +
                "P1_SCORE      INTEGER        NOT NULL,\n" +
                "P2_SCORE      INTEGER        NOT NULL\n" +
                ");\n"

        val CREATE_MATCHES = "Create Table Matches(\n" +
                "M_ID    INTEGER    PRIMARY KEY,\n" +
                "PLAYER_ONE    VARCHAR(35)    NOT NULL,\n" +
                "PLAYER_TWO    VARCHAR(35)    NOT NULL,\n" +
                "P1_SCORE      INTEGER        NOT NULL,\n" +
                "P2_SCORE      INTEGER        NOT NULL\n" +
                ");"

        //Execute the above queries.
        p0?.execSQL(CREATE_GAMES)
        p0?.execSQL(CREATE_MATCHES)
    }

    override fun onUpgrade(p0: SQLiteDatabase?, p1: Int, p2: Int) {
        onCreate(p0)
    }

}