package com.androidatc.loveall

import android.content.ContentValues
import android.content.DialogInterface
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import kotlinx.android.synthetic.main.activity_scorecard.*
import kotlinx.android.synthetic.main.activity_settings.*
import kotlin.math.absoluteValue

class Scorecard : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_scorecard)

        //Declare database variables.
        val dbHelper = TennisDBHelper(this)
        val db = dbHelper.writableDatabase

        //Display Player names and other scorecard information.
        val player_one = intent.getStringExtra("player_one").toString()
        val player_two = intent.getStringExtra("player_two").toString()
        val setsPer = intent.getIntExtra("setsPer", 4)
        val gamesPer = intent.getIntExtra("gamesPer", 6)
        val classicScoring = intent.getBooleanExtra("classic_scoring", false)

        //Initialize variables.
        var p1_score = 0
        var p2_score = 0

        var p1_games = 0
        var p2_games = 0

        var p1_sets = 0
        var p2_sets = 0

        var setsPlayed = 0
        var gamesPlayed = 0

        textView.text = player_one.toString()
        textview2.text = player_two.toString()

        //I will not lie. I do not know what this is needed for.
        val positiveButtonClick = { dialog: DialogInterface, which: Int -> }

        //Show the score in the classic 15-30-DEUCE-ADVANTAGE style.
        //Does nothing if classicScoring is not enabled.
        fun classicScoring(){
            if(classicScoring){
                when(p1_score){
                    1 -> playerOneScore.text = "15"
                    2 -> playerOneScore.text = "30"
                    3 -> playerOneScore.text = "40"
                    4 -> playerOneScore.text = "50"
                }

                when(p2_score){
                    1 -> playerTwoScore.text = "15"
                    2 -> playerTwoScore.text= "30"
                    3 -> playerTwoScore.text= "40"
                    4 -> playerTwoScore.text= "50"
                }
                if((p1_score >= 4 || p2_score >= 4) && (p1_score-p2_score) < 0) {
                    playerTwoScore.text = "ADV"
                    playerOneScore.text= "30"
                }
                else if((p1_score >= 4 || p2_score >= 4) && (p1_score-p2_score) > 0) {
                    playerOneScore.text = "ADV"
                    playerTwoScore.text = "30"
                }
                else if((p1_score >= 4) && (p1_score == p2_score)){
                    playerOneScore.text= "DEU"
                    playerTwoScore.text= "DEU"
                }
            }
        }

        //Reset scores after a game has ended, and show updated set information.
        fun updateGamesSetsBoards(){
            //gamesPlayed += 1
            p1_score = 0
            p2_score = 0
            playerOneScore.text = p1_score.toString()
            playerTwoScore.text = p2_score.toString()
            gameCounter.text = "Game\n${gamesPlayed + 1}"
            setCounter.text = "Set\n${setsPlayed + 1}"
        }

        //Check to see if the match is over. Display the winner if it is, and store the match data in the database.
        fun checkAndDisplayMatchWinner(){
            var message = ""
            if(setsPlayed == setsPer){
                val setDifference = p1_sets - p2_sets
                message = when (setDifference) {
                    1 -> "$player_one has won the match!!!"
                    -1 -> "$player_two has won the match!!!"
                    else -> "The match was a draw."
            }
                val builder = AlertDialog.Builder(this) //This alert displays the winner of the current game.
                with(builder){
                    setTitle("Match Finished!!!")
                    setMessage(message)
                    setPositiveButton("Ok", DialogInterface.OnClickListener(positiveButtonClick))
                    setOnDismissListener{
                        //Once the user closes the window, store match data in database
                        //Prep insert statement.
                        val values = ContentValues().apply {
                            put("player_one", player_one)
                            put("player_two", player_two)
                            put("p1_score", p1_sets)
                            put("p2_score", p2_sets)
                        }

                        //Send to database and return success message.
                        val dbAttempt = db.insert("Matches", null, values)
                        Toast.makeText(applicationContext, "Match added to row: $dbAttempt", Toast.LENGTH_SHORT).show()

                        gamesPlayed = 0
                        setsPlayed = 0
                        updateGamesSetsBoards()

                        var intent = Intent(context, MainActivity::class.java)
                        startActivity(intent)
                    }
                    show()
                }


            }
        }

        //Display winner of game, check to see if the set or match is over, and then reset the scoreboard.
        fun displayGameWinner(player_name: String) {
            val builder = AlertDialog.Builder(this) //This alert displays the winner of the current game.
            with(builder){
                setTitle("GAME FINISHED")
                setMessage("$player_name has won!")
                setPositiveButton("Ok", DialogInterface.OnClickListener(positiveButtonClick))
                show()
            }
            //Increment winner's score. This should be in winDetection().
            if (p1_score > p2_score) {
                p1_games += 1
            } else
                p2_games += 1

            //Check if minimum amount of games per set has been played. Should also be in winDetection().
            if (gamesPlayed >= gamesPer) {
                val gameDifference = p1_games - p2_games
                if (gameDifference.absoluteValue >= 2) {
                    if(p2_games > p1_games)
                        p2_sets += 1
                    else
                        p1_sets += 1
                    //Increment sets played and reset gamesPlayed.
                    setsPlayed += 1
                    gamesPlayed = 0
                    checkAndDisplayMatchWinner()
                }
            }

            updateGamesSetsBoards()
        }

        //Add game results to internal database.
        fun addGameToDatabase(){
            val values = ContentValues().apply {
                put("player_one", player_one)
                put("player_two", player_two)
                put("p1_score", p1_score)
                put("p2_score", p2_score)
            }
            val dbAttempt = db.insert("Games", null, values)

            Toast.makeText(applicationContext, "Game added to row: $dbAttempt", Toast.LENGTH_SHORT).show()
        }

        //This function detects if a player has won the current game.
        fun winDetection(){
            val scoreDifference = p1_score - p2_score
            if(p1_score >= 4 || p2_score >= 4) {
                if(scoreDifference.absoluteValue == 1)
                    return
                else if(scoreDifference <= -2){
                    //Display win message for player 2.
                    addGameToDatabase()
                    displayGameWinner(player_two)

               }
                else if(scoreDifference >= 2){
                    //Display win message for player 1.
                    addGameToDatabase()
                    displayGameWinner(player_one)

                }

                gamesPlayed += 1 //Increment total games played

            }
        }

        //Handle incrementing player one's score.
        scoreButtonOne.setOnClickListener() {
            p1_score += 1
            playerOneScore.text = p1_score.toString()
            winDetection() //Check to see if someone won the game
            classicScoring()
        }

        //Handle incrementing player two's score.
        scoreButtonTwo.setOnClickListener() {
            p2_score += 1
            playerTwoScore.text = p2_score.toString()
            winDetection() //Check to see if someone won the game
            classicScoring()
        }
    }
}